## AI Apps NonProd##

environment = "nonprod"
application_name = "aiapps"
ainonprod_sub_id = "eed58c8e-f08c-4839-9bfe-469f4705d062"  #- This is sub ID for AI-Apps non-prod

#--------------Network--------------------#
vnet_address_spaces = ["10.114.164.0/22"]
subnets = {

aiapps-containerapp-subnet1 = {
  subnet_name = "snet-ai-apps-uaenorth-001"
  subnet_address_prefix = ["10.114.164.0/23"]
  
  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

aiapps-fa-inbound-subnet2 = {
  subnet_name = "snet-fn-app-inbound-uaenorth-001"
  subnet_address_prefix = ["10.114.166.0/25"]

  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

aiapps-fa-outbound-subnet3 = {
  subnet_name = "snet-fn-app-outbound-uaenorth-001"
  subnet_address_prefix = ["10.114.166.128/25"]

  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

aiapps-privatelink-subnet4 = {
  subnet_name = "snet-private-endpoint-uaenorth-001"
  subnet_address_prefix = ["10.114.167.0/26"]

  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

aiapps-appservice-subnet5 = {
  subnet_name = "snet-app-services-uaenorth-001"
  subnet_address_prefix = ["10.114.167.64/26"]

  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

aiapps-logicapp-subnet6 = {
  subnet_name = "snet-logic-app-uaenorth-001"
  subnet_address_prefix = ["10.114.167.128/25"]

  route_table_rules = [
    ["udr-to-fw", "0.0.0.0/0", "VirtualAppliance", "10.115.1.4"]
  ]
}

}
#--------------Network--------------------#

#--------------Cosmos--------------------# 

selected_subnet = "snet-private-endpoint-uaenorth-001"  

entity_name = "aiapps"

# Cosmos DB - Mongo
databases = {
  ailighthouse-prod-platform-db = {
    description    = "Mongo Database"
    max_throughput = 10000
    collections = [{ name = "application", shard_key = "key1" },
      { name = "payment", shard_key = "key2" },
    { name = "refdata", shard_key = "key3" }]
  }
}

#--------------storage--------------------# 

containername = "aifoundry"
